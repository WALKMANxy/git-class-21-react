export interface Person {
    name: string;
    workPosition: string;
    openToWork: boolean;
    profilePhoto?: string;
  }
  

  export default Person;